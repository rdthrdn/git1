# Basic Media Schooling Website Development

## Prerequisite
- Create Github account | [tutorial](https://docs.github.com/en/get-started/start-your-journey/creating-an-account-on-github)
- Create Vercel account | [tutorial](https://thevalleyofcode.com/vercel/0-create-a-vercel-account)
- Install Git | [tutorial](https://phoenixnap.com/kb/how-to-install-git-windows)
- Install Vscode | [tutorial](https://www.liquidweb.com/help-docs/how-to-install-vscode-on-linux-mac-windows/#:~:text=Installing%20VSCode%20on%20Linux%2C%20Mac,that%20you%20can%20begin%20coding.)
- Install Vscode Plugin *Tailwind CSS Intellisense*
